$(function () {
  	$('#tahun_keranjang').datetimepicker({
        viewMode: 'years',
        format:'YYYY'
	});
});


function submit(x){
	var tahun = $('#input_tahun_keranjang').val();

	startloading('Mohon tunggu...');
	$.post(URL+'report/getTbKeranjang',{tahun:tahun}).done(function(data){
		endloading();
		$('#tb_keranjang').html(data);
		
	}).fail(function(){
		endloading();
	});
}


function sh_pemesanan(x, y = null) {
	startloading('Mohon tunggu <br> Sedang mengambil data..');
	item_pj = [];
	try {
		//$('#tb_item_pemesanan').find('thead tr th:eq(4)').remove();
	} catch (e) {} finally {

		$.post(URL + 'transaksi/pemesanan_view', {
			id: x
		}, function(data) {
			endloading();
			if (data.length != 0) {
				var res = $.parseJSON(data);
				// $('.judul_pengajuan').html(res[0].judul);
				$('.no_pemesanan').html(res[0].no_pemesanan);
				$('.tgl_pemesanan').html(format_jam(res[0].tgl_pemesanan));
				$('.nm_pemesan').html(res[0].nama_pemesan);
				$('.v_group').html(res[0].group);
				$('.v_lantai').html(res[0].lantai);
				$('.v_rating').html(res[0].rating);
				$('.v_status').html(res[0].status_txt);
				$('.v_kurir').html(res[0].kurir);
				$('.v_komentar').html(res[0].komentar);


				var td = $('#tb_item_pemesanan').find('tbody');
				td.html('');
				var no = 1;

				if (y == 'verifikasi') {
					$('.verifikasi').load(URL + 'transaksi/verifikasi', function() {
						$(this).show();
					});
				} else {
					$('.verifikasi').html('');
				}

				//$('#tb_item_pemesanan').find('thead tr').append('<th>Item Masuk</th>');
				$('#id_pemesanan_lg').val(res[0].id);

				$.each(res, function(index, el) {
					item_pj.push(res[index].barcode);
					td.append(`
<tr>
<input type="hidden" class="id_it_ps" value="` + res[index].id_it_ps + `">
<input type="hidden" class="id_item" value="` + res[index].id_item + `">
<td>` + no + `</td>
<td>` + res[index].barcode + `</td>
<td>` + res[index].item_name + `</td>
<td class="r-td">` + res[index].h_stock + `</td>
<td class="r-td">` + res[index].qty + `</td>
<td>` + res[index].note + `</td>
</tr>

`);
					if (res[index].qty == res[index].qty_masuk) {
						$('#tb_item_pemesanan').find('tbody tr:eq(' + index + ')').addClass('IComplete bg-green');
					}
					no++;
				});
				$('#modal_view_pemesanan').modal('show');
			} else {
				$.alert('Tidak ada Item / data tidak ditemukan');
			}
		});
	}
}