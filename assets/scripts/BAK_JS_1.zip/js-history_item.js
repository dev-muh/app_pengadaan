$('#tb-history_item').DataTable({
    "autoWidth": true,
    "fixedHeader": true,
    "pageLength": 100,
    "ordering": false
});