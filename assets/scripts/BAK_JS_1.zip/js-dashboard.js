$(document).ready(function() {
	$('.beta').on('click',function(){
	    $.alert({
	      content:'Maaf, halaman belum bisa dibuka'
	    });
	});


});


