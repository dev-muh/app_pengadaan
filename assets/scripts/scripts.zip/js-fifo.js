$.fn.DataTable.ext.errMode = 'none';
$('#tb_in').DataTable({
  "ordering": false,
  "paging":false
});

$('#tb_out').DataTable({
  "ordering": false,
  "paging":false
});
$(function(){
    if(id_item==''||id_item===null){

    }else{
      $('#sel_item').val(id_item);
    }
    
    $('#sel_item').select2({
        width:"100%"
    });
    $('#opt').fadeIn('fast');
});
function ch_it(x,y){
    if(x===null||y===null||x==''||y==''){
        $.alert('Anda belum memilih barang.');
    }else{
        startloading('Mohon tunggu...');
        $('#tb_res').empty();
        $('#res_fifo').hide();

        $('#tb_res').load(URL+'report/fifo?item='+x+'&bulan='+y,function(res,stat,xhr){
            
            if(stat=='success'){
                $('#res_fifo').fadeIn('fast');
                $('#tb_res').html(res);
                endloading();
            }
            if(stat=='error'){
                $('#res_fifo').fadeIn('fast');
                $('#tb_res').html('<center>Error memuat data. Pastikan koneksi internet anda lancar. Coba lagi.</center>');
                endloading();
            }
        });
        // location.replace(URL+'report/fifo?item='+x+'&bulan='+y);  
    }
}

function ch_it_tahunan(x){
    if(x===null||x==''){
        $.alert('Anda belum memilih barang.');
    }else{
        startloading('Mohon tunggu...');
        $('#tb_res').empty();
        $('#res_fifo').hide();

        $('#tb_res').load(URL+'report/fifo?tahunan=yes&item='+x,function(res,stat,xhr){
            
            if(stat=='success'){
                $('#res_fifo').fadeIn('fast');
                $('#tb_res').html(res);
                endloading();
            }
            if(stat=='error'){
                $('#res_fifo').fadeIn('fast');
                $('#tb_res').html('<center>Error memuat data. Pastikan koneksi internet anda lancar. Coba lagi.</center>');
                endloading();
            }
        });
        // location.replace(URL+'report/fifo?tahunan=yes&item='+x);  
    }
}