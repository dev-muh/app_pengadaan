$('#tb-history_item').DataTable({
    "autoWidth": true,
    "fixedHeader": true,
    "pageLength": 100,
    "ordering": false
});

function ch_tahun(id,x){
	startloading('Mohon tunggu. Sedang memproses data...');
	location.href = URL+'report/log_item?id='+id+'&tahun='+x;
}